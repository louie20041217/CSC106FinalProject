            </div>
            <div class="admin-footer">
                <p>&copy; <?php echo date('Y'); ?> Organic Marketplace | Cabadbaran City</p>
            </div>
        </div>
    </div>
    <script src="js/admin_script.js"></script>
</body>
</html>

